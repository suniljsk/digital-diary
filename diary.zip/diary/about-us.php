
<html>
<head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width" />
      <title>Responsive One Page website template</title>
      <link rel="stylesheet" href="css/components.css">
      <link rel="stylesheet" href="css/responsee.css">
      <link rel="stylesheet" href="owl-carousel/owl.carousel.css">
      <link rel="stylesheet" href="owl-carousel/owl.theme.css">
      <link rel="stylesheet" href="css/template-style.css">
      <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
      <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
      <script type="text/javascript" src="js/jquery-ui.min.js"></script>    
      <script type="text/javascript" src="js/modernizr.js"></script>
      <script type="text/javascript" src="js/responsee.js"></script>
      <script type="text/javascript" src="js/template-scripts.js"></script> 
      
   </head>
   <body>          
         <div id="about-us">
            <div class="s-12 m-12 l-6 media-container">
               <img src="img/adout1.jpg" alt="">
            </div>
            <article class="s-12 m-12 l-6">
            <h1><center><b>About Digital Diary</b></center></h1>
<p>Digital Diary is a digital organizer that can store all your contacts, memo, address and schedule records.
       It helps user to store important information on mobile which in turn helps user to check for information.
        It has nice interface which provide user an interactive experience.
         User can even mail all stored information to itself or to a friend which can act as online storage.
 It is developed to store account information, detailed friends information, set reminder or alert for any event, store other information in description form.
</p>
<h1>
Performance and headlines:
</h1>
<p>
It provide feature to store important information digitally.
It is very helpful for every kind of user from a student to businessman to salesmen etc.
User can mail stored information to itself or to a friend.
</p>
<h1>
Benefits:
</h1><p>
User can store important information related to friends, accounts, reminder and other important information.
User can send stored information through mail.
User can search for the stored information through search bar that will help user for easy access.
User will receive an alert for corresponding reminder.
               </p>
               <div class="about-us-icons">
                  <i class="icon-paperplane_ico"></i> <i class="icon-trophy"></i> <i class="icon-clock"></i>
               </div>
            </article>
         </div>
   </body>
</html>
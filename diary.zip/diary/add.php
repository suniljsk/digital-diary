<!DOCTYPE html>
<html>
 <head>
    <meta charset="UTF-8">
    <title></title>
    </head>
    <body>
      <?php
      session_start();
          if($_SESSION['user'])
          {

          }
          else
          {
              header("location : index.php");
          }
          $user = $_SESSION['user'];
          if($SERVER['REQUEST_METHOD'] = "POST")
          {

            $date = date("Y/m/d");
            $entry=$_POST['entry'];

         $conn=mysqli_connect("localhost","root","") or die(mysqli_error());
         mysqli_select_db($conn,"diary") or die("cannot connect the database");   
         
         
         mysqli_query($conn,"INSERT INTO entries(username,entry,date) VALUES('$user','$entry','$date')");


           print '<script>alert("sucessfully inserted");</script>';  
           print '<script>window.location.assign("home.php");</script>'; 
      

          }
          else{
              header("location : home.php");
          }
          ?>
          </body>
          </html>
<!DOCTYPE html>
<html>
 <head>
    <meta charset="UTF-8">
    <title></title>
    </head>
    <body>
      <?php
      session_start();
      $username =$_POST['username'];
      $password =$_POST['password'];
      $conn=mysqli_connect("localhost","root","") or die(mysqli_error());
      mysqli_select_db($conn,"diary") or die("cannot connect the database");   
      $query=mysqli_query($conn,"select * from list where username='$username'");
      $exists=mysqli_num_rows($query);
      $table_users="";
      $table_password="";
      if($exists > 0) 
      {
          while($row = mysqli_fetch_assoc($query)) 
          {
              $table_users = $row['username']; 
              $table_password = $row['password'];
             
       if(($username == $table_users) && ($password == $table_password)) 
       {
                  if ($password == $table_password)
                       {
                           $_SESSION['user'] = $username;
                           header("location: home.php"); 
                       }
       }
       else 
       {
               print '<script>alert("incorrect password");</script>';  
               print '<script>window.location.assign("login.php");</script>'; 
       }
          }
      }
     else{
              print '<script>alert("username does not exists!");</script>';  
              print '<script>window.location.assign("login.php");</script>';    
     }
     ?>
     </body>
     </html>

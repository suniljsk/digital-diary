<?php
session_start();
$user =$_SESSION['user'];


$con=mysqli_connect("localhost","root","");
$db_name="diary";  
  
mysqli_select_db($con,$db_name)or die("cannot select DB");
$sql="SELECT * FROM events ";

$sql2="SELECT * FROM entries WHERE username='$user'";
$result=mysqli_query($con,$sql);
$result2=mysqli_query($con,$sql2);
?> 
<body background="1.jpg">
<table background="1.jpg" width="70%" border="100"  align="center" cellpadding="3" cellspacing="1" bgcolor="#CCCCCC">
<tr>
<td width="13%" align="center" bgcolor="orange" ><i><span style="font-family: Times New Roman;padding-bottom:5px;">USERNAME</span></i></td>

<td width="13%" align="center" bgcolor="blue"><i><span style="font-family: Times New Roman;padding-bottom:5px;">DATE</span></i></td>
<td width="15%" align="center" bgcolor="orange"><i><span style="font-family: Times New Roman;padding-bottom:5px;">ID</span></i></td>
<td width="13%" align="center" bgcolor="blue"><i><span style="font-family: Times New Roman;padding-bottom:5px;">TITLE</span></i></td>
<td width="13%" align="center" bgcolor="orange"><i><span style="font-family: Times New Roman;padding-bottom:5px;">CREATED</span></i></td>
<td width="13%" align="center" bgcolor="blue"><i><span style="font-family: Times New Roman;padding-bottom:5px;">MODIFIED</span></i></td>
<td width="13%" align="center" bgcolor="orange"><i><span style="font-family: Times New Roman;padding-bottom:5px;">STATUS</span></i></td>

</tr>
<?php
while($row = mysqli_fetch_array($result2)){
?>
<?php
while($rows = mysqli_fetch_array($result)){
?>
<tr>

<td align="center" bgcolor="#FFFFFF"><?php echo $row['username']; ?></td>
<td align="center" bgcolor="#FFFFFF"><?php echo $rows['date']; ?></td>
<td align="center" bgcolor="#FFFFFF"><?php echo $rows['id']; ?></td>
<td align="center" bgcolor="#FFFFFF"><?php echo $rows['title']; ?></td>
<td align="center" bgcolor="#FFFFFF"><?php echo $rows['created']; ?></td>
<td align="center" bgcolor="#FFFFFF"><?php echo $rows['modified']; ?></td>
<td align="center" bgcolor="#FFFFFF"><?php echo $rows['status']; ?></td>
</tr>
 </body>
<?php
}}
?>
 

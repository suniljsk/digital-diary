<?php 
session_start();
          if($_SESSION['user'])
          {

          }
          else
          {
              header("location : index.php");
          }
          $user = $_SESSION['user'];
          if($SERVER['REQUEST_METHOD'] = "POST")
          {

            $date = date("Y/m/d");
            
 $conn=mysqli_connect("localhost","root","","diary") or die(mysqli_error());
      mysqli_select_db($conn,"diary") or die("cannot connect the database"); 
      $d=mysqli_query($conn,"SELECT username FROM entries");  
       
      
            $query = mysqli_query($conn,"SELECT * FROM events   "); 
            

      while($row = mysqli_fetch_array($query))
      {
          while($rows = mysqli_fetch_array($d))
      {
          
          echo "username:"."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$rows['username']."<br/>";
      }
           echo "Id:"."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$row['id']."<br/>"."<br/>";
           echo "Title:"."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$row['title']."<br/>"."<br/>";
          echo "Date:"."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$row['date']."<br/>"."<br/>";
          echo "created:"."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$row['created']."<br/>"."<br/>";
          echo "modified:"."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$row['modified']."<br/>"."<br/>";
          echo "status:"."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$row['status']."<br/>"."<br/>";
         
          
         

          echo "<hr/>";
      }}
      
 ?>
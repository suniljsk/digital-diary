<html>
    <head>
    <meta charset="UTF-8">
    <title></title>
    <?php
    session_start();
    
    if($_SESSION['user']) {

    }
    else{
        header("location : index.php");   
    }

    $user =$_SESSION['user'];

    $date =date("m/d/Y");
   ?>
       <style>
       *{
           margin:0;
       } 
    body{
        background-image:url(por6.jpg);  
         background-size: 100% ;
        background-repeat: no; 
    }   
    .d{
        position:absolute;
        top:0;
        width:100%;
        
        background-color: black;
        opacity:0.8;
        text-align: right;
        padding:5px;
        font-size:20px;
        color:white;
    }

    nav ul{
        list-style-type: none;
        display:block;
        padding:0;
    }
#t{
    position:absolute;
    top:68px;
    left:21%;
    width:59%;
    height:72%;
    outline: none !important;
    border:1px solid red;
    box-shadow: 0 0 10px #719ECE;
    background-color: white;
    border-color: black;

}
nav u1 a{
    position:absolute;
    top:59px;
    display:block;
    text-decoration: none;
    
}
article {
    margin-left:30px;
    background-image:url(diary1.jpg);
    padding: 1em;
    overflow: hidden;

}
.txt{
    position:absolute;
    top:100px;
    left:35%;
    width:60%;
    height:60%;
    padding:25px;
    background-image:url(pricing.jpg);
    
    background-size: 45% 100%;
    background-repeat:  repeat-x;   

}
.pwd{
   margin-left: 65%;
   font-family: Aharoni;
   font-size: 16px;
   font-weight:400;
   position:absolute;
   top:130px;
   width:60%;
   height:60%;
   padding:25px;
   background-color:green;
   background-image:url ('diary1.jpg');
   background-size: 45% 100%;
   background-repeat: no-repeat;
   z-index: 1;
}
.p{
top:350px;
    left:190px;
}
.buttons{
    position:absolute;
    top:130px;
    left:70px;
}
.b1{
    width:139%;
}
.b2{
    width:139%;
}
.b3{
    
    width:139%;
}
.b4{
    width:139%;
}
.b5{
    width:139%;
}
.b6{
    width:139%;
}
.button1
{background-color: #808000;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    width:100%;
    color:white;
     font-family: "Times New Roman", Times, serif;
    border: 10px solid transparent;
    padding: 15px;
    font-size: 16px;
    margin: 8px 5px;
    padding:15px 32px;
    cursor: pointer;
    opacity:0.8;
  }
#s{
   position:absolute;
   border: none; 
    color: white; 
    padding: 14px 28px; 
    cursor: pointer; 
    color:red;
     font-family: "Times New Roman", Times, serif;

   top:320px;
   left:83%; 
}
.date{
     position:absolute;
   top:10px;
   
   
   color:white;
}

</style>


</head>
<body style="background-image:url(pricing.jpg); ">  
     <div class="d">
        <p class='date'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php 
        print $date ;?></p>
        <p>welcome &nbsp;             <?php print "$user" ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <a href='logout.php'>logout &nbsp;&nbsp;&nbsp;</p>
     </div>
     
     <div class='buttons'> 
       <div class='b2'>
                <a href='profile.php'><button class='button1'>MY PROFILE</button></a> 
                </div>
             <br/>
             <br/>     
        <div class='b1'>
                <a href='serach2.php'><button class='button1'>MY ENTRIES</button></a> 
                </div>
             <br/>
             <br/>      
         <div class='b3'>
                <a href='upd.php'><button class='button1'>UPDATE </button></a> 
                </div>
                <br/>
             <br/>
                <div class='b4'>
                <a href='index.php'><button class='button1'>EVENTS </button></a> 
                </div>
                <br/>
                <br/>
            
               <div class='b5'>
                <a href='display2.php'><button class='button1'>DISPLAYEVENTS </button></a> 
                           </div>
               <br/>
               <br/>
              
                           </div>
               
        <article>
                
              <div class='txt'> <B><marquee> <font color="orange">WELCOME TO DIGITAL WE MAKE YOU BETTER..!!!</font> </marquee><B>
              <form action='add.php' method='post'>
              <textarea id='t' name='entry'></textarea>
              <button type="submit" id='s' width="48" height="48">Save entry</button>
             

              </form>
              </div>

                  
          
         </article>   
           

         </body>

        </html> 
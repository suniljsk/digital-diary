<html>
<head>
    <meta charset="UTF-8">
    <title></title>
    <style>
    body{
        margin:0;
        padding: 0;
        background: url(diary1.jpg);
        background-size: cover;
        background-position:center;
        font-family: sans-serif;
    }

    .loginbox{
        width: 420px;
        height: 420px;
        background: #2f4f4f;
        color:#fff;
        top: 50%;
        right: 190px ;
        position: absolute;
        transform: translate(-50%,-50%);
        box-sizing: border-box;
        padding: 70px 30px; 
    }
        .avatar{
        width: 100px;
        height: 100px;
        border-radius: 50%;
        position: absolute;
        top: -50px;
        left: 37%;
        left: calc(50% -50px);
        
    }
    h1 {
        margin: 0;
        padding: 0 0 20px;
        text-align: center;
        font-size: 22px;
    }
    .loginbox p{
        margin: 0;
        padding: 0;
        font-weight: bold;
    }
    .loginbox input{
        width: 100%;
        margin-bottom: 20px;

    }
    loginbox input[type="text"] , input[type="password"],input[type="text"]{
        border:none;
        border-bottom: 1px solid #fff;
        background: transparent;
        outline: none;
        height: 40px;
        color: #fff;
        font-size: 16px;
    }
    .loginbox input[type="submit"]
    {
        border:none;
        outline: none;
        height: 40px;
        background: #fb2525;
        color: #fff;
        font-size: 18px;
        border-radius: 20px;
    } 
    .loginbox input[type="submit"]:hover
    {
        cursor: pointer;
        background: #ffc107;
        color: #000;
    }
    .loginbox a{
        text-decoration: none;
        font-size: 12px;
        line-height: 20px;
        color: darkgrey;

    }
    .loginbox a:hover
    {
        color:#ffc107;
    }
    
   </style></head>
   <body>
   
   <div class='loginbox'>
            <img src='avatar1.jpg' class="avatar">
                    <h1>login page</h1>
      
          <form action="checklogin.php" method="post">
           <p>username<p>
          <input type="text" name="username" required="required" placeholder="username"/>
           <p>password<p>
          <input type="password" name="password" required="required" placeholder="password"/>
          
          <input type="submit" value="login"/>
          
                
<a href="about-us.php">ABOUT US</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  <a href="registeration.php">REGISTER OR SIGNUP</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  <a href="faq.html">FAQ?</a>        
            
          </form>
    </div>
    </body>
</html>
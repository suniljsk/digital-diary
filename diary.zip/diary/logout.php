<?php 
   session_start();  
   session_destroy();  
     
     
   $logout = "login.php";          
   header("Location: $logout");  
   exit();  
  

?> 
<script language="javascript"> 
function confirm() { 
    if ( confirm("Are you sure you want to log out?")) 
      window.location = "login.php"; 
} 
</script>
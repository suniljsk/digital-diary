<html>
<head><style>
.avatar{
        width: 100px;
        height: 100px;
        border-radius: 50%;
        position: absolute;
        top: -50px;
        left: 44%;
        left: calc(50% -50px);
        
    }
.txt{
    
    position:absolute;
    top:70px;
    right:20%;
    width:60%;
    height: 70%;
    padding:25px;
    background-color: #2f4f4f;
    
    background-size: 45% 100%;
    background-repeat:  repeat-x;

}
</style>
</head>
<body style="background-image:url(diary1.jpg); ">


<article>
        <div class="txt">
        <img src='avatar1.jpg' class="avatar">
          <pre><br/>
<span style="font-family: forte;padding-bottom:5px;"><center> My Profile</center> </span>
</pre>
<?php 
session_start();
$user =$_SESSION['user'];

 $conn=mysqli_connect("localhost","root","","diary") or die(mysqli_error());
      mysqli_select_db($conn,"diary") or die("cannot connect the database");   
            $query = mysqli_query($conn,"SELECT * FROM list WHERE username= '$user'"); 

      while($row = mysqli_fetch_array($query))
      {
          
          echo "<hr/>"."<br/>";
          echo "First Name:"."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$row['fname']."<br/>"."<br/>";
          echo "Last Name:"."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$row['lname']."<br/>"."<br/>";
          echo "Email Id:"."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$row['email']."<br/>"."<br/>";
          echo "Address:"."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$row['address']."<br/>"."<br/>";
          echo "Zipcode:"."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$row['zipcode']."<br/>"."<br/>";
          echo "Phone no"."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$row['phn']."<br/>"."<br/>";


          echo "<hr/>";
      }
 ?>
 <br/><pre>
 <a href="upd.php"><button>Edit</button></a>
         </pre>
        </div>
    
    </article>
    </body>
    </html>
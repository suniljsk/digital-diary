<html>
<head>
     <meta charset="UTF-8">
     <title>
     </title></head>
 <body>
     <?php
     $fname=$_POST['fname'];
     $lname=$_POST['lname'];
     $username=$_POST['username'];
     $password=$_POST['password'];
     $email=$_POST['email'];
     $address=$_POST['address'];
     $zipcode=$_POST['zipcode'];
     $phn=$_POST['phn'];

    $conn=mysqli_connect("localhost","root","") or die(mysqli_error());  
    mysqli_select_db($conn,"diary") or die("cannot connect the database");   
    $query=mysqli_query($conn,"select * from list WHERE username='$username'");
    $count=mysqli_num_rows($query);

    if($count>0){
        print '<script>alert("username taken");</script>';
        print '<script>window.location.assign("index.php");</script>';

        }
        else
        {
            $queries="INSERT INTO list VALUES('$fname','$lname','$username','$password','$email','$address','$zipcode','$phn')";
            mysqli_query($conn,$queries);
             print '<script>alert("successfully registered!");</script>';
             print '<script>window.location.assign("login.php");</script>';

            }
?>
</body>
</html>
<html>
<head>

    <title>
        </title>
    </head>
<body>
    <?php
    session_start();
    $opwd=$_POST['opwd'];
    $npwd=$_POST['npwd'];
    $user=$_SESSION['user'];
    $conn=mysqli_connect("localhost","root","","diary") or die(mysqli_error());
    mysqli_select_db($conn,"diary") or die("cannot connect the database");   
    $result=mysqli_query($conn,"select * from list where username='$user'");
      
      while($row=mysqli_fetch_array($result)){
          if($row['password']==$opwd){
              mysqli_query($conn,"UPDATE list set password='$npwd' where username='$user'")or die(mysqli_error());
              $_SESSION['user']=$user;
                        print '<script>alert("sucessfully updated!!!");</script>';  
                        print '<script>window.location.assign("upd.php");</script>'; 
          }
        else
        {
           print '<script>alert("old password does not match");</script>';  
           print '<script>window.location.assign("upd.php");</script>';   
        }
      }
      ?>
      </body>
      </html>
<?php 
session_start();
$user =$_SESSION['user'];

 $conn=mysqli_connect("localhost","root","","diary") or die(mysqli_error());
      mysqli_select_db($conn,"diary") or die("cannot connect the database");   
            $query = mysqli_query($conn,"SELECT * FROM entries WHERE username= '$user'"); 

      while($row = mysqli_fetch_array($query))
      {
          
          echo "<hr/>"."<br/>";
          echo "User Name:"."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$row['username']."<br/>"."<br/>";
          echo "Entry:"."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$row['entry']."<br/>"."<br/>";
          echo "Date:"."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$row['date']."<br/>"."<br/>";
         

          echo "<hr/>";
      }
 ?>
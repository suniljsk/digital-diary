<html>
    <head>
    <meta charset="UTF-8">
    <title></title>
    <?php
    session_start();
    
    if($_SESSION['user']) {

    }
    else{
        header("location : index.php");   
    }

    $user =$_SESSION['user'];

    $date =date("m/d/Y");
   ?>
       <style>
       *{
           margin:0;
       } 
    body{
        background-image:url ('diary.jpg');
         background-size: 100% ;
        background-repeat: no-repeat; 
    }   
    .d{
        position:absolute;
        top:0;
        width:100%;
        background-color: black;
        opacity:0.8;
        text-align: right;
        padding:5px;
        font-size:20px;
        color:white;
    }

    nav ul{
        list-style-type: none;
        display:block;
        padding:0;
    }
#t{
    position:absolute;
    top:98px;
    left:21%;
    width:59%;
    height:72%;
    background-color: whitesmoke;
    border-color: whitesmoke;

}
nav u1 a{
    position:absolute;
    top:59px;
    display:block;
    text-decoration: none;
    
}
article {
    margin-left:30px;

    padding: 1em;
    overflow: hidden;

}
.txt{
    position:absolute;
    top:130px;
    left:35%;
    width:60%;
    height:60%;
    padding:25px;
    background-color: #2f4f4f;
    background-image:url ('diary.jpg');
    background-size: 45% 100%;
    background-repeat: no-repeat;

}
.pwd{
   margin-left: 65%;
   font-family: Aharoni;
   font-size: 16px;
   font-weight:400;
   position:absolute;
   top:130px;
   width:60%;
   height:60%;
   padding:25px;
   background-color: #2f4f4f;
   background-image:url ('diary.jpg');
   background-size: 45% 100%;
   background-repeat: no-repeat;
   z-index: 1;
}
.buttons{
    position:absolute;
    top:130px;
    left:70px;
}
.b1{
    width:139%;
}
.b2{
    width:139%;
}
.b3{
    width:139%;
}
.button1
{
    width:100%;
    font-size: 16px;
    margin: 8px 5px;
    padding:15px 32px;
    cursor: pointer;
    opacity:0.8;
  }
#s{
   position:absolute;
   top:420px;
   left:83%; 
}
.date{
     position:absolute;
   top:10px;
   
   color:white;
}

</style>


</head>



  <body style="background-image:url(diary1.jpg);">
     <div class="d">
        <div class='date'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php
        print $date ;?></div>
        <p>welcome &nbsp;             <?php print "$user" ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <a href='logout.php'><img src='logout.'height="8%">&nbsp;&nbsp;&nbsp;</p>
     </div>
     <br/><br/>
     <div class='buttons'> 
       <div class='b2'>
                <a href='profile.php'><button class='button1'>MY PROFILE</button></a> 
                </div>
             <br/>
             <br/>     
        <div class='b1'>
                <a href='search2.php'><button class='button1'>MY ENTRIES</button></a> 
                </div>
             <br/>
             <br/>      
         <div class='b3'>
                <a href='home.php'><button class='button1'>New Entry </button></a> 
                </div>
               </div>
<div class="pwd">
    <pre>

 <span style="font-family: Aharoni;color: gray"> change your password</span>

    <form action="resetpwd.php" method="POST">
       <input type="text" name="opwd" placeholder="Old password">


       <input type="text" name="npwd" placeholder="New password">


            <input type="submit" value="update">
                    </form>
             </pre>
        </div>
    <article>
        <div class='txt'>
            <pre>
<form action='update.php' method='POST'>
       <input type="text" name="fname" placeholder="First Name">


       <input type="text" name="lname" placeholder="Last Name">  


       <input type="text" name="email" placeholder="Email Id">


       <input type="text" name="address" placeholder="Address">


       <input type="text" name="zipcode" placeholder="Zip code">


       <input type="text" name="phn" placeholder="Phone No.">

       <input type="submit" value="update"   placeholder="Last Name">

</form>




       </form>
  </pre>

         </div>

     </article>


     </body>


    <html>

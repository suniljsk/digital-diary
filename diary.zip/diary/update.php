<html>
<head>

    <title>
        </title>
    </head>
<body>
    <?php
    session_start();
 
    
    if($_SESSION['user']) {

    }
    else{
        header("location : index.php");   
    }


    $user =$_SESSION['user'];
  if($_SERVER['REQUEST_METHOD'] = "GET")
  {

    $conn=mysqli_connect("localhost","root","") or die(mysqli_error());
    mysqli_select_db($conn,"diary") or die("cannot connect the database");


       if(isset($_POST['fname'])){
           $fname = $_POST['fname'];
       }
       else
       {
           $fname=mysqli_query($conn,"select fname from list where username=$user;");
       }


       if(isset($_POST['lname'])){
           $lname = $_POST['lname'];
       }else{
           $lname=mysqli_query($conn,"select lname from list where username=$user;");
       }


       if(isset($_POST['email'])){
           $email = $_POST['email'];
       }else{
           $email=mysqli_query($conn,"select email from list where username=$user;");
       }


       if(isset($_POST['address'])){
           $address = $_POST['address'];
       }else{
           $address=mysqli_query($conn,"select address from list where username=$user;");
       }



       if(isset($_POST['zipcode'])){
           $zipcode = $_POST['zipcode'];
       }else{
           $zipcode=mysqli_query($conn,"select zipcode from list where username=$user;");
       }



       if(isset($_POST['phn'])){
           $phn = $_POST['phn'];
       }else{
           $phn=mysqli_query($conn,"select phn from list where username=$user;");
       }

          



    mysqli_query($conn,"UPDATE list set fname = '$fname',
           lname ='$lname',
           email ='$email',
           address = '$address',
           zipcode='$zipcode',
           phn='$phn' where username='$user' ") or die(mysql_error());
    
    print '<script>alert("sucessfully updated!!!");</script>';  
                        print '<script>window.location.assign("upd.php");</script>'; 
          }
        else
        {
           header("location: home.php"); 
        }
      
       ?>

</body>
</html>


